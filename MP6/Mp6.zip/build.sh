make clean 
make 
./copykernel.sh 
bochs -f bochsrc.bxrc > out.out
